
import { GoogleGenAI } from "@google/genai";
import { ContentGenerationRequest, Language } from "../types";

export const generateContent = async (req: ContentGenerationRequest): Promise<string> => {
  /* Strictly following the guideline: Always use this initialization pattern. */
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const systemInstruction = `
    You are UniWrite AI, a world-class Senior Content Architect. 
    Your primary directive is to generate 100% ORIGINAL, plagiarism-free, and copyright-safe content.
    
    CRITICAL RULES:
    1. Generate content as if the internet does not exist. Use first-principles reasoning.
    2. Never rewrite or mimic existing authors, books, or online articles.
    3. Use independent wording, unique structures, and original examples.
    4. If Language is "Auto Detect", detect the language from the "topic" and "audience" fields and respond in THAT SAME language.
    5. Ensure high SEO value without keyword stuffing.
    6. Tone must strictly adhere to: ${req.tone}.
    7. Format output as: ${req.format}.
    
    CONTEXT:
    - Content Type: ${req.type}
    - Topic: ${req.topic}
    - Language Requested: ${req.language}
    - Target Audience: ${req.audience}
    - Word Count Goal: ~${req.wordCount} words.
    - Additional Keywords: ${req.keywords || 'None'}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate the ${req.type} about "${req.topic}" for ${req.audience}. 
                Follow the system instructions for originality and language.`,
      config: {
        systemInstruction,
        temperature: 0.8,
        topP: 0.9,
      },
    });

    /* Directly accessing the .text property as per guidelines */
    return response.text || "No content generated.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate content. Please try again later.");
  }
};

export const calculateSEOScore = (content: string, keywords?: string): number => {
  if (!content) return 0;
  
  let score = 50; // Base score
  
  // Length check
  if (content.split(' ').length > 300) score += 10;
  
  // Structure check
  if (content.includes('#') || content.includes('**')) score += 10;
  
  // Keyword density
  if (keywords) {
    const kws = keywords.split(',').map(k => k.trim().toLowerCase());
    const contentLower = content.toLowerCase();
    let found = 0;
    kws.forEach(kw => {
      if (contentLower.includes(kw)) found++;
    });
    score += (found / kws.length) * 30;
  }
  
  return Math.min(Math.round(score), 100);
};
