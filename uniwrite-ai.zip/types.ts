
export enum ContentType {
  BLOG = 'Blog Article',
  WEBSITE = 'Website Content',
  PRODUCT = 'Product Description',
  MARKETING = 'Ads & Marketing Copy',
  YOUTUBE = 'YouTube Script',
  SOCIAL = 'Instagram/Facebook Caption',
  EMAIL = 'Email Copy',
  RESUME = 'Resume & Cover Letter',
  LEGAL = 'General Legal (Non-advisory)',
  CUSTOM = 'Custom Writing'
}

export enum Language {
  AUTO = 'Auto Detect',
  ENGLISH = 'English',
  HINDI = 'Hindi',
  HINGLISH = 'Hinglish',
  SPANISH = 'Spanish',
  FRENCH = 'French',
  GERMAN = 'German'
}

export enum Tone {
  PROFESSIONAL = 'Professional',
  FRIENDLY = 'Friendly',
  PERSUASIVE = 'Persuasive',
  CASUAL = 'Casual',
  AUTHORITATIVE = 'Authoritative'
}

export enum OutputFormat {
  MARKDOWN = 'Markdown',
  PARAGRAPH = 'Plain Text',
  BULLETS = 'Bullet Points',
  HTML = 'HTML'
}

export interface ContentGenerationRequest {
  topic: string;
  type: ContentType;
  language: Language;
  tone: Tone;
  wordCount: number;
  audience: string;
  keywords?: string;
  format: OutputFormat;
}

export interface SavedContent {
  id: string;
  timestamp: number;
  request: ContentGenerationRequest;
  result: string;
  seoScore: number;
}
