
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Generator from './pages/Generator';
import History from './pages/History';
import LandingPage from './pages/LandingPage';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState('landing');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Simple state persistence for demo purposes
  useEffect(() => {
    const session = localStorage.getItem('uniwrite_session');
    if (session) {
      setIsLoggedIn(true);
      setActivePage('dashboard');
    }
  }, []);

  const handleStart = () => {
    setIsLoggedIn(true);
    setActivePage('dashboard');
    localStorage.setItem('uniwrite_session', 'active');
  };

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard />;
      case 'generator':
        return <Generator />;
      case 'history':
        return <History />;
      case 'pricing':
        return (
          <div className="flex flex-col items-center justify-center py-12 space-y-6">
             <h2 className="text-3xl font-bold">Premium Plans</h2>
             <p className="text-slate-500">Coming soon! Stay tuned for unlimited generation.</p>
             <button onClick={() => setActivePage('dashboard')} className="px-6 py-2 bg-indigo-600 text-white rounded-xl">Back to Safety</button>
          </div>
        );
      case 'settings':
        return (
          <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl border border-slate-200">
            <h2 className="text-2xl font-bold mb-6">User Settings</h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <div>
                  <p className="font-semibold">Dark Mode</p>
                  <p className="text-sm text-slate-500">Coming soon in next update</p>
                </div>
                <div className="w-12 h-6 bg-slate-300 rounded-full"></div>
              </div>
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                <div>
                  <p className="font-semibold">Email Notifications</p>
                  <p className="text-sm text-slate-500">Weekly content digest</p>
                </div>
                <div className="w-12 h-6 bg-indigo-600 rounded-full relative">
                   <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  if (activePage === 'landing' && !isLoggedIn) {
    return <LandingPage onStart={handleStart} />;
  }

  return (
    <Layout activePage={activePage} setActivePage={setActivePage}>
      {renderContent()}
    </Layout>
  );
};

export default App;
