
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface SEOIndicatorProps {
  score: number;
}

const SEOIndicator: React.FC<SEOIndicatorProps> = ({ score }) => {
  const data = [
    { name: 'Score', value: score },
    { name: 'Remaining', value: 100 - score },
  ];

  const getColor = (s: number) => {
    if (s >= 80) return '#10b981'; // Green
    if (s >= 50) return '#f59e0b'; // Amber
    return '#ef4444'; // Red
  };

  return (
    <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col items-center">
      <h3 className="text-sm font-medium text-slate-500 mb-2">SEO Score</h3>
      <div className="w-32 h-32 relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={30}
              outerRadius={45}
              startAngle={180}
              endAngle={0}
              paddingAngle={0}
              dataKey="value"
            >
              <Cell fill={getColor(score)} />
              <Cell fill="#f1f5f9" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex items-center justify-center pt-6">
          <span className="text-2xl font-bold" style={{ color: getColor(score) }}>{score}</span>
        </div>
      </div>
      <p className="text-xs text-slate-400 mt-[-20px] text-center">
        {score >= 80 ? 'Excellent Optimization' : score >= 50 ? 'Good Potential' : 'Needs Improvement'}
      </p>
    </div>
  );
};

export default SEOIndicator;
