
import React from 'react';
import { Sparkles, Zap, Shield, Globe, ArrowRight, Star } from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="min-h-screen bg-slate-50 overflow-hidden">
      {/* Navbar */}
      <nav className="fixed top-0 inset-x-0 h-20 bg-white/80 backdrop-blur-md z-50 border-b border-slate-200 px-6 lg:px-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
            <Sparkles size={24} />
          </div>
          <span className="text-xl font-bold tracking-tight">UniWrite AI</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-semibold text-slate-600">
          <a href="#features" className="hover:text-indigo-600">Features</a>
          <a href="#security" className="hover:text-indigo-600">Originality</a>
          <a href="#pricing" className="hover:text-indigo-600">Pricing</a>
        </div>
        <button 
          onClick={onStart}
          className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          Get Started
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-40 pb-20 px-6 lg:px-12 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-50 text-indigo-700 rounded-full text-sm font-bold animate-bounce">
              <Zap size={14} className="fill-indigo-700" />
              <span>Version 3.0 is live!</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-extrabold text-slate-900 leading-[1.1]">
              Write Anything. <br />
              <span className="gradient-text">Original & Faster.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-xl mx-auto lg:mx-0">
              Generate 100% plagiarism-free content in Hindi, English, and more. 
              Built for creators who demand authenticity and high SEO performance.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
              <button 
                onClick={onStart}
                className="w-full sm:w-auto px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-2xl shadow-indigo-200"
              >
                Start Writing Free <ArrowRight size={20} />
              </button>
              <div className="flex -space-x-3">
                {[1,2,3,4].map(i => (
                  <img key={i} src={`https://picsum.photos/seed/${i}/100/100`} className="w-10 h-10 rounded-full border-2 border-white" alt="user" />
                ))}
                <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center text-[10px] font-bold text-slate-500">
                  +2k
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-white p-4 rounded-3xl shadow-2xl border border-slate-200 relative z-10 animate-in fade-in slide-in-from-right-12 duration-1000">
              <div className="bg-slate-50 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-400" />
                    <div className="w-3 h-3 rounded-full bg-amber-400" />
                    <div className="w-3 h-3 rounded-full bg-emerald-400" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Editor Mode</span>
                </div>
                <div className="space-y-3">
                  <div className="h-4 bg-slate-200 rounded w-3/4 animate-pulse" />
                  <div className="h-4 bg-slate-200 rounded w-full animate-pulse delay-75" />
                  <div className="h-4 bg-slate-200 rounded w-5/6 animate-pulse delay-150" />
                  <div className="h-4 bg-indigo-100 rounded w-2/3 animate-pulse delay-300" />
                </div>
                <div className="pt-4 flex items-center justify-between border-t border-slate-200">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-emerald-100 rounded text-emerald-600 flex items-center justify-center">
                      <Star size={12} className="fill-emerald-600" />
                    </div>
                    <span className="text-xs font-bold text-slate-500">98% Plagiarism Free</span>
                  </div>
                  <button className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg">Copy Content</button>
                </div>
              </div>
            </div>
            {/* Background elements */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-indigo-200/20 blur-[100px] -z-10" />
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 bg-white px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl font-bold text-slate-900">Engineered for Quality</h2>
            <p className="text-slate-500 max-w-2xl mx-auto">We use advanced first-principles reasoning to ensure your content stands out from the AI noise.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: 'Zero Plagiarism', desc: 'Content generated from scratch, never paraphrased from the web.', icon: Shield },
              { title: 'Multilingual Native', desc: 'Write in English, Hindi, Hinglish and 50+ other languages naturally.', icon: Globe },
              { title: 'SEO Optimized', desc: 'Auto-calculates keyword density and structure for top ranking.', icon: Zap },
            ].map((f, i) => (
              <div key={i} className="p-8 bg-slate-50 rounded-3xl space-y-4 hover:bg-white hover:shadow-xl transition-all border border-transparent hover:border-slate-100">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
                  <f.icon size={24} />
                </div>
                <h3 className="text-xl font-bold">{f.title}</h3>
                <p className="text-slate-600 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
