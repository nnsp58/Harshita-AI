
import React, { useState } from 'react';
/* Added Sparkles to the lucide-react import */
import { 
  Send, 
  Copy, 
  Download, 
  RotateCw, 
  ChevronRight, 
  Languages, 
  Target, 
  Type as TypeIcon,
  Search,
  CheckCircle2,
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { 
  ContentType, 
  Language, 
  Tone, 
  OutputFormat, 
  ContentGenerationRequest, 
  SavedContent 
} from '../types';
import { generateContent, calculateSEOScore } from '../services/geminiService';
import SEOIndicator from '../components/SEOIndicator';

const Generator: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string>('');
  const [seoScore, setSeoScore] = useState<number>(0);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<ContentGenerationRequest>({
    topic: '',
    type: ContentType.BLOG,
    language: Language.AUTO,
    tone: Tone.PROFESSIONAL,
    wordCount: 500,
    audience: 'General',
    keywords: '',
    format: OutputFormat.MARKDOWN
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.topic) {
      setError("Please provide a topic or title.");
      return;
    }

    setLoading(true);
    setError(null);
    setResult('');
    
    try {
      const content = await generateContent(formData);
      setResult(content);
      const score = calculateSEOScore(content, formData.keywords);
      setSeoScore(score);

      // Save to local storage for persistence in this demo
      const saved: SavedContent = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: Date.now(),
        request: formData,
        result: content,
        seoScore: score
      };
      const existing = JSON.parse(localStorage.getItem('uniwrite_history') || '[]');
      localStorage.setItem('uniwrite_history', JSON.stringify([saved, ...existing]));

    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Settings Form */}
      <div className="lg:col-span-4 space-y-6">
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Target size={14} className="text-indigo-600" /> Topic / Title
            </label>
            <input 
              type="text" 
              placeholder="e.g., The Impact of Renewable Energy"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              value={formData.topic}
              onChange={(e) => setFormData({...formData, topic: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <TypeIcon size={14} className="text-indigo-600" /> Content Type
              </label>
              <select 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                value={formData.type}
                onChange={(e) => setFormData({...formData, type: e.target.value as ContentType})}
              >
                {Object.values(ContentType).map(type => <option key={type} value={type}>{type}</option>)}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <Languages size={14} className="text-indigo-600" /> Language
              </label>
              <select 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none appearance-none"
                value={formData.language}
                onChange={(e) => setFormData({...formData, language: e.target.value as Language})}
              >
                {Object.values(Language).map(lang => <option key={lang} value={lang}>{lang}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Tone</label>
              <select 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                value={formData.tone}
                onChange={(e) => setFormData({...formData, tone: e.target.value as Tone})}
              >
                {Object.values(Tone).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-sm font-semibold text-slate-700">Word Count</label>
              <input 
                type="number" 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                value={formData.wordCount}
                onChange={(e) => setFormData({...formData, wordCount: parseInt(e.target.value)})}
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Target Audience</label>
            <input 
              type="text" 
              placeholder="e.g., Tech-savvy teenagers"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.audience}
              onChange={(e) => setFormData({...formData, audience: e.target.value})}
            />
          </div>

          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700 flex items-center gap-2">
              <Search size={14} className="text-indigo-600" /> SEO Keywords (Optional)
            </label>
            <input 
              type="text" 
              placeholder="comma separated keywords"
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
              value={formData.keywords}
              onChange={(e) => setFormData({...formData, keywords: e.target.value})}
            />
          </div>

          <button 
            type="submit"
            disabled={loading}
            className={`
              w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg
              ${loading ? 'bg-slate-200 text-slate-400' : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-100'}
            `}
          >
            {loading ? (
              <RotateCw className="animate-spin" size={20} />
            ) : (
              <>Generate <Send size={20} /></>
            )}
          </button>
        </form>

        {result && (
          <div className="animate-in fade-in zoom-in-95 duration-300">
            <SEOIndicator score={seoScore} />
          </div>
        )}
      </div>

      {/* Editor/Result Area */}
      <div className="lg:col-span-8 flex flex-col h-full space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 p-4 rounded-xl text-red-700 flex items-center gap-3">
            <AlertCircle size={20} />
            <p className="font-medium">{error}</p>
          </div>
        )}

        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden min-h-[600px]">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2 text-slate-500 text-sm">
              <FileTextIcon size={18} />
              <span>Editor Preview</span>
            </div>
            {result && (
              <div className="flex items-center gap-2">
                <button 
                  onClick={handleCopy}
                  className="p-2 hover:bg-white rounded-lg text-slate-600 transition-colors flex items-center gap-2 text-sm font-medium"
                >
                  {copied ? <CheckCircle2 size={18} className="text-emerald-500" /> : <Copy size={18} />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
                <button className="p-2 hover:bg-white rounded-lg text-slate-600 transition-colors">
                  <Download size={18} />
                </button>
              </div>
            )}
          </div>

          <div className="flex-1 p-8 overflow-y-auto">
            {!result && !loading && (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                  <PenToolIcon size={32} />
                </div>
                <div className="text-center">
                  <p className="font-bold text-slate-600 text-lg">Your workspace is ready</p>
                  <p className="text-sm">Enter your details and click generate to start writing.</p>
                </div>
              </div>
            )}

            {loading && (
              <div className="space-y-6 animate-pulse">
                <div className="h-8 bg-slate-100 rounded w-3/4"></div>
                <div className="space-y-3">
                  <div className="h-4 bg-slate-100 rounded"></div>
                  <div className="h-4 bg-slate-100 rounded"></div>
                  <div className="h-4 bg-slate-100 rounded w-5/6"></div>
                </div>
                <div className="space-y-3">
                  <div className="h-4 bg-slate-100 rounded"></div>
                  <div className="h-4 bg-slate-100 rounded w-4/5"></div>
                </div>
              </div>
            )}

            {result && (
              <div className="prose prose-slate max-w-none prose-headings:font-bold prose-headings:text-slate-900 prose-p:text-slate-600 prose-li:text-slate-600 whitespace-pre-wrap font-sans leading-relaxed text-slate-800">
                {result}
              </div>
            )}
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-100">
            {/* Using Sparkles icon which is now imported */}
            <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold flex items-center gap-2">
              <Sparkles size={12} className="text-indigo-400" /> 100% Original Content Guarantee
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper internal component
const FileTextIcon = ({size}: {size: number}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><line x1="10" y1="9" x2="8" y2="9"></line></svg>
);

/* Renamed local component to PenToolIcon to avoid naming collisions */
const PenToolIcon = ({size}: {size: number}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 19 7-7 3 3-7 7-3-3z"></path><path d="m18 13-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="m2 2 5 5"></path><path d="m11 11 5 5"></path></svg>
);

export default Generator;
