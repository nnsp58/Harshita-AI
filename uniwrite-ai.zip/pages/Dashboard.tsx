
import React from 'react';
/* Added Sparkles to the lucide-react import */
import { FileText, Clock, Award, TrendingUp, Sparkles } from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    { label: 'Words Generated', value: '12,450', icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Total Projects', value: '48', icon: Award, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Average SEO', value: '86%', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Time Saved', value: '120h', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Welcome back, John!</h2>
          <p className="text-slate-500 mt-1">Ready to create some amazing content today?</p>
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-medium hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200">
            Upgrade Plan
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-4">
              <div className={`${stat.bg} ${stat.color} p-3 rounded-xl`}>
                <stat.icon size={24} />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">{stat.label}</p>
                <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold mb-4">Recent Projects</h3>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl hover:bg-indigo-50 transition-colors cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center border border-slate-200">
                      <FileText className="text-slate-400 group-hover:text-indigo-500" size={20} />
                    </div>
                    <div>
                      <p className="font-semibold">The Future of AI Content Writing</p>
                      <p className="text-xs text-slate-400">Blog Article • 2 days ago</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs font-bold rounded">92 SEO</span>
                    <button className="p-2 text-slate-400 hover:text-indigo-600">
                      <Clock size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-600 p-6 rounded-2xl text-white shadow-xl shadow-indigo-200 relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-lg font-bold mb-2">Power User Tip</h3>
              <p className="text-indigo-100 text-sm leading-relaxed">
                Use our "Auto-Detect" language feature to write in Hinglish or regional dialects naturally.
              </p>
              <button className="mt-4 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg text-sm font-medium transition-colors">
                Learn More
              </button>
            </div>
            {/* Using Sparkles icon which is now imported */}
            <Sparkles className="absolute -right-4 -bottom-4 w-32 h-32 text-white/10 rotate-12" />
          </div>
          
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold mb-4">Quick Templates</h3>
            <div className="grid grid-cols-2 gap-3">
              <button className="p-3 text-left bg-slate-50 rounded-xl hover:bg-indigo-50 transition-colors border border-transparent hover:border-indigo-100">
                <p className="text-xs font-bold text-indigo-600 uppercase">Blog</p>
                <p className="text-sm font-medium">Article Intro</p>
              </button>
              <button className="p-3 text-left bg-slate-50 rounded-xl hover:bg-indigo-50 transition-colors border border-transparent hover:border-indigo-100">
                <p className="text-xs font-bold text-indigo-600 uppercase">Social</p>
                <p className="text-sm font-medium">Ad Caption</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
