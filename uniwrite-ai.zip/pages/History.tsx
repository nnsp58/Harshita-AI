
import React, { useState, useEffect } from 'react';
import { Search, Filter, Trash2, ExternalLink, Calendar, Hash } from 'lucide-react';
import { SavedContent } from '../types';

const History: React.FC = () => {
  const [history, setHistory] = useState<SavedContent[]>([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('uniwrite_history') || '[]');
    setHistory(saved);
  }, []);

  const deleteItem = (id: string) => {
    const updated = history.filter(item => item.id !== id);
    setHistory(updated);
    localStorage.setItem('uniwrite_history', JSON.stringify(updated));
  };

  const filtered = history.filter(item => 
    item.request.topic.toLowerCase().includes(search.toLowerCase()) ||
    item.request.type.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search your library..."
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 font-medium">
          <Filter size={18} />
          Filters
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filtered.length > 0 ? filtered.map((item) => (
          <div key={item.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-indigo-200 transition-all group">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 flex-shrink-0">
                <Hash size={24} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{item.request.topic}</h3>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1">
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{item.request.type}</span>
                  <div className="flex items-center gap-1 text-xs text-slate-400">
                    <Calendar size={12} />
                    {new Date(item.timestamp).toLocaleDateString()}
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                    item.seoScore >= 80 ? 'bg-emerald-100 text-emerald-700' : 
                    item.seoScore >= 50 ? 'bg-amber-100 text-amber-700' : 
                    'bg-red-100 text-red-700'
                  }`}>
                    {item.seoScore} SEO
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-4 md:pt-0 border-t md:border-t-0 border-slate-100">
              <button className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 rounded-lg hover:bg-indigo-50 hover:text-indigo-600 transition-colors font-medium">
                <ExternalLink size={16} />
                Open
              </button>
              <button 
                onClick={() => deleteItem(item.id)}
                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>
        )) : (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4">
              <Search size={40} className="text-slate-300" />
            </div>
            <p className="font-bold text-slate-600">No projects found</p>
            <p className="text-sm">Try searching for something else or create a new project.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default History;
